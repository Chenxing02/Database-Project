-- MySQL dump 10.13  Distrib 8.0.40, for macos14 (arm64)
--
-- Host: localhost    Database: product
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `supplier_data`
--

DROP TABLE IF EXISTS `supplier_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_data` (
  `Supplier_id` int NOT NULL,
  `Name` text,
  `Phone` bigint DEFAULT NULL,
  `email` text,
  `Adress` text,
  PRIMARY KEY (`Supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_data`
--

LOCK TABLES `supplier_data` WRITE;
/*!40000 ALTER TABLE `supplier_data` DISABLE KEYS */;
INSERT INTO `supplier_data` VALUES (100009,'Kasey Ough',7074362462,'koughg@exblog.jp','342 Summit Trail'),(100015,'Carine Abramovic',4753478766,'cabramovic22@mtv.com','62 Oxford Terrace'),(100023,'Claude Radbond',3571385987,'cradbond1d@noaa.gov','8496 Browning Terrace'),(100048,'Arlen Stigger',6258817071,'astigger1h@unblog.fr','65 Melvin Place'),(100054,'Benton Pochin',2819889002,'bpochin1q@geocities.jp','97 Aberg Parkway'),(100060,'Nari De la croix',8096915039,'nde28@wordpress.org','61011 Reinke Court'),(100073,'Arabela Furbank',7326433900,'afurbankl@wikipedia.org','1 Moland Trail'),(100123,'Wesley Suffe',3058600115,'wsuffe5@trellian.com','6 Welch Crossing'),(100129,'Jedd Lenchenko',4507265905,'jlenchenkof@qq.com','961 Sloan Court'),(100133,'Justina Issakov',7079246339,'jissakov2p@eepurl.com','3 Pierstorff Junction'),(100139,'Ernaline Brewett',1103004409,'ebrewett15@1und1.de','4 Northfield Pass'),(100147,'Mellie Schroter',9351717417,'mschroter2j@weebly.com','421 Erie Terrace'),(100158,'Paulette Eggleson',2491394526,'pegglesonz@jalbum.net','43258 Dahle Street'),(100168,'Ewen Shevlin',3209725018,'eshevlins@bloglines.com','3 Anzinger Circle'),(100177,'Ninetta Ryce',6617625757,'nryce27@webmd.com','0927 7th Drive'),(100184,'Katalin Tee',5527883967,'kteeb@opera.com','04439 Lakewood Gardens Avenue'),(100189,'Gunther Gandy',9846698513,'ggandy19@phoca.cz','80318 Ronald Regan Pass'),(100199,'Kasey Tucker',9368194270,'ktucker2n@photobucket.com','44 Mallard Way'),(100202,'Marlow Silbert',6164917071,'msilbert1s@patch.com','4907 Barnett Circle'),(100217,'Cherilyn O\'Fallon',6508480949,'cofallon26@taobao.com','9632 Veith Alley'),(100230,'Halsey Sowle',1441109727,'hsowle1t@spiegel.de','64354 Monica Hill'),(100232,'Lucius McEntagart',6724907315,'lmcentagart2g@wordpress.com','6726 Buena Vista Trail'),(100251,'Elsworth Wetherill',2641016019,'ewetherill10@si.edu','0 8th Place'),(100252,'Hillard Cassidy',2103262067,'hcassidyn@wp.com','0 David Terrace'),(100254,'Rick Blenkinsop',6416297421,'rblenkinsop4@edublogs.org','3774 Maryland Terrace'),(100266,'Madalena Mawd',1285531022,'mmawd1g@163.com','2 Gerald Lane'),(100281,'Louisette Scohier',1843723839,'lscohier1p@techcrunch.com','3721 Sullivan Pass'),(100297,'Dianemarie Burne',4249898645,'dburne2q@delicious.com','4916 Scott Park'),(100300,'Felipa Birchenhead',6758100243,'fbirchenhead1i@cnn.com','13 Union Crossing'),(100308,'Marie Brand-Hardy',5202039376,'mbrandhardyh@gizmodo.com','073 Springview Lane'),(100309,'Kingsly Hutsby',5141192813,'khutsby12@chronoengine.com','70929 Algoma Point'),(100318,'Modestia McEnhill',3467385701,'mmcenhill2h@jimdo.com','37 6th Alley'),(100359,'Tanny Tether',5335294406,'ttether20@skyrock.com','152 Corry Pass'),(100364,'Dougie Magenny',1185787246,'dmagenny9@hhs.gov','14 Marcy Hill'),(100373,'Glenn Tomasino',6614445271,'gtomasino1v@ovh.net','05291 Carioca Avenue'),(100392,'Harmonia Lamberti',3224534457,'hlamberti2c@elegantthemes.com','2 Superior Junction'),(100404,'Aleksandr Fishpool',1502274165,'afishpoolw@netvibes.com','6 Luster Center'),(100405,'Carrol Foye',6818376071,'cfoyev@buzzfeed.com','26069 Paget Plaza'),(100436,'Brigid Kinchington',6935713504,'bkinchington8@redcross.org','130 Del Sol Park'),(100438,'Leona Spurden',7965046176,'lspurden24@jimdo.com','56679 Bay Center'),(100452,'Angele Pettipher',5728164031,'apettipher1u@google.com.au','6 Hoard Parkway'),(100458,'Eugenia Filer',6304404854,'efiler2e@scientificamerican.com','07012 Bonner Parkway'),(100462,'Denise Shuker',8298009258,'dshukery@sciencedaily.com','1 Vermont Point'),(100463,'Adora Heersma',9959057783,'aheersmad@blogspot.com','507 Center Parkway'),(100490,'Vale Rosling',9199140222,'vrosling2a@stanford.edu','150 Kenwood Trail'),(100494,'Penelope Landeaux',8785795414,'plandeaux16@vkontakte.ru','8918 Sullivan Trail'),(100503,'Kele Rau',6054900250,'krau0@github.io','473 Stuart Way'),(100507,'Ogdon Demogeot',6602613883,'odemogeot1f@1688.com','83 Arrowood Plaza'),(100509,'Romola Egdal',1842701602,'regdal23@ehow.com','75987 Kennedy Circle'),(100522,'Elicia Mulder',8082597125,'emulder25@alibaba.com','7503 Eliot Avenue'),(100542,'Baxter Butterley',8182879831,'bbutterley1e@archive.org','76285 Lake View Alley'),(100551,'Rik Gabbot',8159232905,'rgabbot1y@yandex.ru','5507 Tennyson Lane'),(100554,'Alexis Milligan',5784808860,'amilligan29@home.pl','6 Union Parkway'),(100569,'Jasmina Awcock',8845337645,'jawcock2f@constantcontact.com','07914 Dunning Circle'),(100575,'Norene Balazin',2099263290,'nbalazin2i@zdnet.com','5322 Division Point'),(100585,'Vania Tomasutti',4912480718,'vtomasutti2o@theglobeandmail.com','5578 Blackbird Parkway'),(100607,'Eunice Draycott',5772394709,'edraycott2d@intel.com','13955 Del Sol Way'),(100608,'Madelle Krzysztof',2966114598,'mkrzysztof3@shutterfly.com','98 Kim Place'),(100612,'Letizia Bakster',1686923317,'lbaksterp@bravesites.com','0025 Upham Road'),(100614,'Duffy Berthouloume',4165776142,'dberthouloume11@un.org','2 Hermina Pass'),(100632,'Jeanine Whitton',2395597331,'jwhitton18@ezinearticles.com','5 Continental Avenue'),(100637,'Arron Nowak',2948062894,'anowak2k@weebly.com','216 Burrows Drive'),(100644,'Danya Pikett',5622805096,'dpikett2m@phpbb.com','16689 Mifflin Circle'),(100654,'Aveline Jorg',2435448690,'ajorg17@mail.ru','2 Trailsway Alley'),(100665,'Susette Kingsnod',5612428927,'skingsnod6@google.com','4 Red Cloud Park'),(100666,'Edan Lynnitt',6542452392,'elynnittm@exblog.jp','2 Steensland Alley'),(100675,'Westbrook Vere',3792536713,'wvere1j@mapy.cz','96817 Goodland Plaza'),(100677,'Arnold Jarrelt',7036495284,'ajarreltr@toplist.cz','1411 Sage Plaza'),(100680,'Hamid Derges',3409063525,'hderges1x@yellowpages.com','845 Kipling Hill'),(100681,'Arnuad Rosario',4155528547,'arosario2l@quantcast.com','6042 Haas Crossing'),(100683,'Perren Bodesson',7015509654,'pbodesson2r@blogs.com','1 Lawn Street'),(100684,'Steffen Syddie',1693206756,'ssyddie1n@slashdot.org','14832 Porter Road'),(100703,'Daffi Tschersich',9833681179,'dtschersich2b@dyndns.org','53 American Circle'),(100717,'Correy Graeser',8826325786,'cgraeser1c@webs.com','173 Armistice Park'),(100720,'Guido Tregear',2155240685,'gtregear1k@ucoz.com','783 Corscot Street'),(100751,'Wolfie Scopes',6173665891,'wscopes1@chronoengine.com','9721 Forest Drive'),(100753,'Brynne Reace',5346260714,'breacec@netscape.com','7 Montana Alley'),(100755,'Sampson Outerbridge',6098169060,'souterbridget@shop-pro.jp','38 Mariners Cove Center'),(100782,'Vaclav Cobbald',6103754309,'vcobbaldi@github.io','20430 Kropf Road'),(100787,'Darelle Gowdy',5522750731,'dgowdy21@hud.gov','7467 Bultman Alley'),(100796,'Meriel Lechelle',9718803791,'mlechellej@hatena.ne.jp','13063 Bellgrove Alley'),(100833,'Philippa Leathers',7923725775,'pleathers14@independent.co.uk','7162 Alpine Center'),(100844,'Reinhold Sydney',8253602700,'rsydneyk@cnn.com','9 Katie Terrace'),(100851,'Glenine Surphliss',8379204974,'gsurphlissx@si.edu','871 Roth Plaza'),(100852,'Wiley Denisovich',1107175086,'wdenisovichu@google.pl','5 Alpine Trail'),(100861,'Kelley Rickett',9968533562,'krickettq@gmpg.org','424 Thierer Pass'),(100864,'Vale Pedlow',4746521122,'vpedlowo@vkontakte.ru','1 Goodland Junction'),(100865,'Monti Careless',5536792364,'mcareless1b@mapquest.com','6003 Red Cloud Way'),(100874,'Tana Truckett',3856150565,'ttruckett2@instagram.com','66869 Dryden Avenue'),(100886,'Gnni Edworthy',1361204874,'gedworthy1w@yale.edu','576 Dryden Court'),(100898,'Christine McDunlevy',4968075312,'cmcdunlevy1o@hhs.gov','8075 Jana Parkway'),(100908,'Viole Elmar',4182526855,'velmar7@spiegel.de','4301 Kim Lane'),(100920,'Tara Elcocks',6647600407,'telcocks1z@ebay.com','3907 Michigan Court'),(100941,'Abelard Inchley',7175834668,'ainchleye@ning.com','23560 Sloan Alley'),(100952,'Bess Klimontovich',4223754563,'bklimontovich1m@nationalgeographic.com','0 Southridge Place'),(100960,'Sari Kaindl',7568606088,'skaindl13@theglobeandmail.com','40 Namekagon Place'),(100963,'Smith Burnside',5389021440,'sburnside1r@de.vu','544 Grim Pass'),(100980,'Jerrold McCall',8375411024,'jmccalla@cargocollective.com','3 Cody Alley'),(100985,'Fabiano Denisyev',4894468146,'fdenisyev1l@usa.gov','566 Walton Avenue'),(100996,'Lissa Riha',1317828887,'lriha1a@ftc.gov','2 Holy Cross Park');
/*!40000 ALTER TABLE `supplier_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-17 20:04:32
